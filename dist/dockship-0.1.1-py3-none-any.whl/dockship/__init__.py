"""

Run Dockship models in Docker containers
"""

# Version of dockship package
__version__ = "0.1.1"

